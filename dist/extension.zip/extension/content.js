(() => {
  var __defProp = Object.defineProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // src/adapters/chatgpt.js
  var chatgpt_exports = {};
  __export(chatgpt_exports, {
    getPrompt: () => getPrompt2,
    getSiteName: () => getSiteName2,
    setPrompt: () => setPrompt2
  });

  // src/adapters/generic.js
  var generic_exports = {};
  __export(generic_exports, {
    getPrompt: () => getPrompt,
    getSiteName: () => getSiteName,
    setPrompt: () => setPrompt,
    simulateFrameworkInput: () => simulateFrameworkInput
  });
  function findLargestInput() {
    const candidates = [];
    const textareas = document.querySelectorAll("textarea");
    textareas.forEach((t) => candidates.push(t));
    const editables = document.querySelectorAll('[contenteditable="true"]');
    editables.forEach((e) => candidates.push(e));
    const textboxes = document.querySelectorAll('[role="textbox"]');
    textboxes.forEach((t) => {
      if (!candidates.includes(t)) {
        candidates.push(t);
      }
    });
    if (candidates.length === 0) return null;
    let largest = null;
    let maxLen = -1;
    for (const el of candidates) {
      let text = "";
      if (el.tagName.toLowerCase() === "textarea" || el.tagName.toLowerCase() === "input") {
        text = el.value || "";
      } else {
        text = el.innerText || el.textContent || "";
      }
      if (text.length > maxLen) {
        maxLen = text.length;
        largest = el;
      }
    }
    return largest;
  }
  function simulateFrameworkInput(element, value) {
    if (!element) return;
    element.focus();
    const isTextareaOrInput = element.tagName.toLowerCase() === "textarea" || element.tagName.toLowerCase() === "input";
    if (isTextareaOrInput) {
      const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value").set;
      if (nativeInputValueSetter) {
        nativeInputValueSetter.call(element, value);
      } else {
        element.value = value;
      }
    } else {
      element.innerText = value;
    }
    element.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
    element.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
    element.dispatchEvent(new InputEvent("input", { bubbles: true, data: value, inputType: "insertText" }));
  }
  function getPrompt() {
    const el = findLargestInput();
    if (!el) return "";
    if (el.tagName.toLowerCase() === "textarea" || el.tagName.toLowerCase() === "input") {
      return el.value || "";
    } else {
      return el.innerText || el.textContent || "";
    }
  }
  function setPrompt(text) {
    const el = findLargestInput();
    if (el) {
      simulateFrameworkInput(el, text);
      return true;
    }
    return false;
  }
  function getSiteName() {
    return "Generic";
  }

  // src/adapters/chatgpt.js
  function getPrompt2() {
    const specificEl = document.querySelector("#prompt-textarea");
    if (specificEl) {
      const text = specificEl.tagName.toLowerCase() === "textarea" ? specificEl.value : specificEl.innerText || specificEl.textContent;
      if (text) return text;
    }
    return getPrompt();
  }
  function setPrompt2(text) {
    const specificEl = document.querySelector("#prompt-textarea");
    if (specificEl) {
      simulateFrameworkInput(specificEl, text);
      return true;
    }
    return setPrompt(text);
  }
  function getSiteName2() {
    return "ChatGPT";
  }

  // src/adapters/claude.js
  var claude_exports = {};
  __export(claude_exports, {
    getPrompt: () => getPrompt3,
    getSiteName: () => getSiteName3,
    setPrompt: () => setPrompt3
  });
  function getPrompt3() {
    const specificEl = document.querySelector('div[contenteditable="true"].ProseMirror');
    if (specificEl) {
      return specificEl.innerText || "";
    }
    return getPrompt();
  }
  function setPrompt3(text) {
    const specificEl = document.querySelector('div[contenteditable="true"].ProseMirror');
    if (specificEl) {
      specificEl.textContent = text;
      specificEl.dispatchEvent(new Event("input", { bubbles: true }));
      return true;
    }
    return setPrompt(text);
  }
  function getSiteName3() {
    return "Claude";
  }

  // src/adapters/gemini.js
  var gemini_exports = {};
  __export(gemini_exports, {
    getPrompt: () => getPrompt4,
    getSiteName: () => getSiteName4,
    setPrompt: () => setPrompt4
  });
  function getPrompt4() {
    const specificEl = document.querySelector('rich-textarea div[contenteditable="true"]');
    if (specificEl) {
      return specificEl.innerText || "";
    }
    return getPrompt();
  }
  function setPrompt4(text) {
    const specificEl = document.querySelector('rich-textarea div[contenteditable="true"]');
    if (specificEl) {
      specificEl.textContent = text;
      specificEl.dispatchEvent(new Event("input", { bubbles: true }));
      specificEl.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    }
    return setPrompt(text);
  }
  function getSiteName4() {
    return "Gemini";
  }

  // src/storage.js
  var STORAGE_KEY = "ai_prompt_reframer_settings";
  var DEFAULT_SETTINGS = {
    geminiApiKey: "",
    improvementMode: "Standard",
    // Quick, Standard, Expert
    targetOverride: "auto"
    // auto, chatgpt, claude, gemini, generic
  };
  async function getSettings() {
    if (typeof chrome !== "undefined" && chrome.storage) {
      return new Promise((resolve) => {
        chrome.storage.local.get([STORAGE_KEY], (result) => {
          if (result[STORAGE_KEY]) {
            resolve({ ...DEFAULT_SETTINGS, ...result[STORAGE_KEY] });
          } else {
            resolve(DEFAULT_SETTINGS);
          }
        });
      });
    }
    if (typeof window !== "undefined" && window.localStorage) {
      try {
        const stored = window.localStorage.getItem(STORAGE_KEY);
        if (stored) {
          return { ...DEFAULT_SETTINGS, ...JSON.parse(stored) };
        }
      } catch (e) {
        console.warn("AI Prompt Reframer: Failed to read from localStorage", e);
      }
    }
    return DEFAULT_SETTINGS;
  }
  async function saveSettings(settings) {
    const current = await getSettings();
    const updated = { ...current, ...settings };
    if (typeof chrome !== "undefined" && chrome.storage) {
      return new Promise((resolve) => {
        chrome.storage.local.set({ [STORAGE_KEY]: updated }, () => {
          resolve(true);
        });
      });
    }
    if (typeof window !== "undefined" && window.localStorage) {
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
        return true;
      } catch (e) {
        console.error("AI Prompt Reframer: Failed to save to localStorage", e);
        return false;
      }
    }
    return false;
  }

  // src/adapters/index.js
  async function getAdapter() {
    const settings = await getSettings();
    if (settings.targetOverride && settings.targetOverride !== "auto") {
      switch (settings.targetOverride) {
        case "chatgpt":
          return chatgpt_exports;
        case "claude":
          return claude_exports;
        case "gemini":
          return gemini_exports;
        case "generic":
          return generic_exports;
      }
    }
    const host = window.location.hostname;
    if (host.includes("chatgpt.com")) return chatgpt_exports;
    if (host.includes("claude.ai")) return claude_exports;
    if (host.includes("gemini.google.com")) return gemini_exports;
    return generic_exports;
  }

  // src/settings.js
  async function showSettings(onCloseCallback) {
    let existingModal = document.getElementById("ai-prompt-reframer-settings");
    if (existingModal) {
      existingModal.remove();
    }
    const current = await getSettings();
    const modal = document.createElement("div");
    modal.id = "ai-prompt-reframer-settings";
    Object.assign(modal.style, {
      position: "fixed",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
      width: "400px",
      backgroundColor: "#ffffff",
      borderRadius: "8px",
      boxShadow: "0 4px 24px rgba(0,0,0,0.15)",
      zIndex: "999999",
      fontFamily: "system-ui, -apple-system, sans-serif",
      padding: "24px",
      color: "#111827"
    });
    modal.innerHTML = `
        <h2 style="margin: 0 0 16px 0; font-size: 1.25rem;">Reframer Settings</h2>
        
        <div style="margin-bottom: 16px;">
            <label style="display: block; font-size: 0.875rem; font-weight: 500; margin-bottom: 4px;">Gemini API Key</label>
            <input type="password" id="pr-api-key" placeholder="AIzaSy..." value="${current.geminiApiKey}" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 4px; box-sizing: border-box;">
            <small style="display: block; font-size: 0.75rem; color: #6b7280; margin-top: 4px;">Stored locally. Never shared.</small>
        </div>

        <div style="margin-bottom: 16px;">
            <label style="display: block; font-size: 0.875rem; font-weight: 500; margin-bottom: 4px;">Improvement Mode</label>
            <select id="pr-improve-mode" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 4px;">
                <option value="Quick" ${current.improvementMode === "Quick" ? "selected" : ""}>Quick (Fastest)</option>
                <option value="Standard" ${current.improvementMode === "Standard" ? "selected" : ""}>Standard</option>
                <option value="Expert" ${current.improvementMode === "Expert" ? "selected" : ""}>Expert (Deep reasoning)</option>
            </select>
        </div>

        <div style="margin-bottom: 24px;">
            <label style="display: block; font-size: 0.875rem; font-weight: 500; margin-bottom: 4px;">Adapter Override</label>
            <select id="pr-target-override" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 4px;">
                <option value="auto" ${current.targetOverride === "auto" ? "selected" : ""}>Auto-Detect</option>
                <option value="chatgpt" ${current.targetOverride === "chatgpt" ? "selected" : ""}>ChatGPT</option>
                <option value="claude" ${current.targetOverride === "claude" ? "selected" : ""}>Claude</option>
                <option value="gemini" ${current.targetOverride === "gemini" ? "selected" : ""}>Gemini</option>
                <option value="generic" ${current.targetOverride === "generic" ? "selected" : ""}>Generic Textarea</option>
            </select>
        </div>

        <div style="display: flex; justify-content: flex-end; gap: 8px;">
            <button id="pr-settings-close" style="padding: 8px 16px; border: 1px solid #d1d5db; background: transparent; border-radius: 4px; cursor: pointer;">Close</button>
            <button id="pr-settings-save" style="padding: 8px 16px; border: none; background: #2563eb; color: white; border-radius: 4px; cursor: pointer; font-weight: 500;">Save Settings</button>
        </div>
    `;
    document.body.appendChild(modal);
    document.getElementById("pr-settings-close").addEventListener("click", () => {
      modal.remove();
      if (onCloseCallback) onCloseCallback();
    });
    document.getElementById("pr-settings-save").addEventListener("click", async () => {
      const apiKey = document.getElementById("pr-api-key").value.trim();
      const mode = document.getElementById("pr-improve-mode").value;
      const target = document.getElementById("pr-target-override").value;
      await saveSettings({
        geminiApiKey: apiKey,
        improvementMode: mode,
        targetOverride: target
      });
      modal.remove();
      if (onCloseCallback) onCloseCallback();
    });
  }

  // src/api.js
  async function improvePrompt(originalText) {
    const settings = await getSettings();
    const apiKey = settings.geminiApiKey;
    if (!apiKey) {
      throw new Error("API_KEY_MISSING");
    }
    const mode = settings.improvementMode || "Standard";
    let systemInstruction = `You are an expert AI Prompt Engineer responsible for transforming vague or low-quality user inputs into highly structured, context-aware, and high-performing prompts for large language models.

Your task is to analyze the given user input and reframe it into an optimized prompt that maximizes clarity, completeness, and output quality.

### Instructions:

1. **Understand Intent**
   * Identify the core goal of the user (e.g., explanation, coding, debugging, writing, comparison, design).
   * Infer missing context when necessary, but do not hallucinate specifics.

2. **Apply Intelligent Structuring**
   * Convert the input into a well-defined prompt using:
     * Role assignment (e.g., "You are a senior software engineer...")
     * Clear objective
     * Context definition
     * Step-by-step instructions (only if beneficial)
     * Output format constraints

3. **Adapt Based on Task Type**
   * Explanation \u2192 include structure, examples, and clarity
   * Coding \u2192 include tech stack, constraints, and expected output
   * Writing \u2192 include tone, audience, and format
   * Debugging \u2192 include error analysis, root cause, and fixes

4. **Control Output Quality**
   * Ensure the final prompt is:
     * Specific but not overly verbose
     * Structured but not rigid
     * Optimized for real-world usefulness

5. **Add Coverage Guarantees**
   * Ensure no critical aspect of the task is missing
   * Expand vague inputs into complete, actionable instructions

6. **Output Format**
   * Return ONLY the improved prompt
   * Do not include explanations or commentary`;
    if (mode === "Quick") {
      systemInstruction += "\n\n**Additional Constraint**: Be concise, fast, and highly structured (Quick Mode).";
    } else if (mode === "Expert") {
      systemInstruction += "\n\n**Additional Constraint**: Use advanced reasoning frameworks and break down complex requests into granular sub-tasks (Expert Mode).";
    }
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
    const requestBody = {
      systemInstruction: {
        parts: [{ text: systemInstruction }]
      },
      contents: [
        {
          role: "user",
          parts: [{ text: originalText }]
        }
      ],
      generationConfig: {
        temperature: 0.3,
        // Low temperature for deterministic/professional output
        maxOutputTokens: 2048
      }
    };
    try {
      if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
        return new Promise((resolve, reject) => {
          chrome.runtime.sendMessage(
            { action: "FETCH_GEMINI", url, body: requestBody },
            (response2) => {
              if (chrome.runtime.lastError) {
                return reject(new Error(chrome.runtime.lastError.message));
              }
              if (response2.error) {
                return reject(new Error(response2.error));
              }
              resolve(response2.text);
            }
          );
        });
      }
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(requestBody)
      });
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`API_ERROR: ${response.status} - ${errorText}`);
      }
      const data = await response.json();
      const candidate = data.candidates?.[0];
      if (!candidate || !candidate.content || !candidate.content.parts || !candidate.content.parts[0].text) {
        throw new Error(`UNEXPECTED_RESPONSE: ${JSON.stringify(data)}`);
      }
      return candidate.content.parts[0].text;
    } catch (e) {
      if (e.message === "API_KEY_MISSING") throw e;
      console.error("Gemini API Fetch failed:", e);
      throw e;
    }
  }

  // src/main-ui.js
  function showMainApp(improvedTextPromise, onReplaceCallback) {
    let existingModal = document.getElementById("ai-prompt-reframer-main");
    if (existingModal) existingModal.remove();
    const modal = document.createElement("div");
    modal.id = "ai-prompt-reframer-main";
    Object.assign(modal.style, {
      position: "fixed",
      top: "20px",
      right: "20px",
      width: "400px",
      backgroundColor: "#ffffff",
      borderRadius: "8px",
      boxShadow: "0 4px 24px rgba(0,0,0,0.15)",
      zIndex: "999999",
      fontFamily: "system-ui, -apple-system, sans-serif",
      padding: "24px",
      color: "#111827",
      display: "flex",
      flexDirection: "column",
      gap: "16px"
    });
    const header = document.createElement("div");
    header.style.display = "flex";
    header.style.justifyContent = "space-between";
    header.style.alignItems = "center";
    const title = document.createElement("h2");
    title.textContent = "AI Prompt Reframer";
    title.style.margin = "0";
    title.style.fontSize = "1.25rem";
    const settingsBtn = document.createElement("button");
    settingsBtn.innerHTML = "\u2699\uFE0F";
    settingsBtn.style.background = "none";
    settingsBtn.style.border = "none";
    settingsBtn.style.cursor = "pointer";
    settingsBtn.style.fontSize = "1.2rem";
    settingsBtn.addEventListener("click", () => {
      showSettings();
    });
    header.appendChild(title);
    header.appendChild(settingsBtn);
    const bodyContainer = document.createElement("div");
    bodyContainer.id = "pr-body-container";
    bodyContainer.innerHTML = `
        <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100px;">
           <span style="display: inline-block; animation: pr-spin 1s linear infinite;">\u23F3</span>
           <p style="margin-top: 8px; color: #6b7280; font-size: 0.875rem;">Optimizing Prompt with Gemini...</p>
        </div>
        <style>
          @keyframes pr-spin { 100% { transform: rotate(360deg); } }
        </style>
    `;
    const controls = document.createElement("div");
    controls.style.display = "none";
    controls.style.justifyContent = "flex-end";
    controls.style.gap = "8px";
    const closeBtn = document.createElement("button");
    closeBtn.textContent = "Close";
    closeBtn.style.padding = "8px 16px";
    closeBtn.style.border = "1px solid #d1d5db";
    closeBtn.style.background = "transparent";
    closeBtn.style.borderRadius = "4px";
    closeBtn.style.cursor = "pointer";
    closeBtn.addEventListener("click", () => modal.remove());
    const copyBtn = document.createElement("button");
    copyBtn.textContent = "Copy";
    copyBtn.style.padding = "8px 16px";
    copyBtn.style.border = "1px solid #d1d5db";
    copyBtn.style.background = "#f3f4f6";
    copyBtn.style.borderRadius = "4px";
    copyBtn.style.cursor = "pointer";
    const replaceBtn = document.createElement("button");
    replaceBtn.textContent = "Replace & Close";
    replaceBtn.style.padding = "8px 16px";
    replaceBtn.style.border = "none";
    replaceBtn.style.background = "#2563eb";
    replaceBtn.style.color = "white";
    replaceBtn.style.borderRadius = "4px";
    replaceBtn.style.fontWeight = "500";
    replaceBtn.style.cursor = "pointer";
    controls.appendChild(closeBtn);
    controls.appendChild(copyBtn);
    controls.appendChild(replaceBtn);
    modal.appendChild(header);
    modal.appendChild(bodyContainer);
    modal.appendChild(controls);
    document.body.appendChild(modal);
    improvedTextPromise.then((improvedText) => {
      bodyContainer.innerHTML = "";
      const textArea = document.createElement("textarea");
      textArea.value = improvedText;
      textArea.readOnly = true;
      textArea.style.width = "100%";
      textArea.style.height = "150px";
      textArea.style.padding = "12px";
      textArea.style.border = "1px solid #d1d5db";
      textArea.style.borderRadius = "4px";
      textArea.style.boxSizing = "border-box";
      textArea.style.fontFamily = "monospace";
      textArea.style.fontSize = "0.875rem";
      textArea.style.resize = "vertical";
      bodyContainer.appendChild(textArea);
      controls.style.display = "flex";
      copyBtn.addEventListener("click", () => {
        navigator.clipboard.writeText(improvedText);
        copyBtn.textContent = "Copied!";
        setTimeout(() => {
          copyBtn.textContent = "Copy";
        }, 2e3);
      });
      replaceBtn.addEventListener("click", () => {
        if (onReplaceCallback) onReplaceCallback(improvedText);
        modal.remove();
      });
    }).catch((error) => {
      bodyContainer.innerHTML = `
            <div style="color: #ef4444; background: #fee2e2; border: 1px solid #f87171; padding: 12px; border-radius: 4px; font-size: 0.875rem;">
                <strong>API Request Failed</strong>
                <p style="margin: 4px 0 0 0; word-break: break-all;">${error.message}</p>
            </div>
        `;
      controls.innerHTML = "";
      controls.appendChild(closeBtn);
      controls.style.display = "flex";
      if (error.message.includes("API_KEY_MISSING")) {
        showSettings();
        modal.remove();
      }
    });
  }

  // src/index.js
  async function init() {
    const adapter = await getAdapter();
    const originalPrompt = adapter.getPrompt();
    if (!originalPrompt || originalPrompt.trim() === "") {
      alert("AI Prompt Reframer: No detectable text input found. Focus on the text area and type something first!");
      return;
    }
    const settings = await getSettings();
    if (!settings.geminiApiKey) {
      showSettings(() => init());
      return;
    }
    const promise = improvePrompt(originalPrompt);
    showMainApp(promise, (improvedText) => {
      const success = adapter.setPrompt(improvedText);
      if (!success) {
        alert("Failed to automatically inject text into this website. Use the Copy button instead.");
      }
    });
  }

  // src/content.js
  if (!window.__AI_PROMPT_REFRAMER_INJECTED__) {
    window.__AI_PROMPT_REFRAMER_INJECTED__ = true;
  }
  init();
})();
